# Pre-requisites:
pip3 install ipywidgets --user  
pip3 install mpld3 --user  
pip3 install notebook --user  
pip3 install jupyter --user  
 
env PATH=~/.local/bin:$PATH jupyter nbextension enable --py widgetsnbextension --user  
  
# Run notebook  
env PATH=~/.local/bin:$PATH jupyter notebook  
